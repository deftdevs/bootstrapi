MySQL jira home export
--------------------

1. Create a database
https://confluence.atlassian.com/display/JIRA/Connecting+JIRA+to+MySQL
DROP DATABASE jiradb;
CREATE DATABASE jiradb CHARACTER SET utf8 COLLATE utf8_bin;

2. Download a standalone version of JIRA
https://www.atlassian.com/software/jira/download-archives\
Version: 6.3

// extract and set home directory
unzip atlassian-jira-6.3.zip
cd atlassian-jira-6.3-standalone/
mkdir home
echo "jira.home=`pwd`/home" > atlassian-jira/WEB-INF/classes/jira-application.properties

// db driver
download
https://maven.atlassian.com/service/local/repositories/central/content/mysql/mysql-connector-java/5.1.34/mysql-connector-java-5.1.34.jar

cp mysql-connector-java-5.1.34.jar lib/

// start jira
bin/start-jira.sh

// configure db

// insert following license
AAACbA0ODAoPeNp1VE1z2jAUvPtXaKa3zBhsIKFhxgewTSAJX8aQhKYHIT9AiZE8kgyhv77Cxh2bttfV03u7+1b69gIRmkOCGm1k253WbafZQg+jEDWsRtP4hNMShKScOfadZbWt782mbazxfs157ZkSYBL8iKpzgT8O/WAaDOe+saFyBycoKsJTAk5fY/4J3jvIgwPEPAFhkJgfQFTK3AyqVI3T/RrEZLOQmopza7icKUzUGO/BwVtGcfSLfhqEs01Nw/QAjhIpGNNUkB2W4GEFTsO2bdO6M622UZqWtfD8pf88mfpBceJ/JVScsmtTu2ENioH+CNO4NHEOQlMdek7v4T40XxfLlvm0Wg3MnmW/FB6VCX1QgStaH4dBF/lMgUgElVfWnOVUjNFAnAIj1bo4LxlguXNGruX2Z+70SB9mYu89iWhMnvvBShzc5tcmHPDZcPG62JKPN/uxPsKHaHVcduW23boP124q3518auG3G6dScxvzCKRjXW0949TLoP9JKOv9R0iISAldx9WUuBew0ujm5mY8Cc3+JDCnwcRbuOFwMjYXc18f6BugNxWh9QmpHaBLM82JaN4CJYJ/AFHox06p5L1Tr2/1UlSMpaSY1Qjf1y8OmpDf+FlDHkeMKxRRqQRdpwp0ZyqR4ohoR/hex7Bm6DBo2QzrhfwVGM3LDfxu6Htm7+1MshRTwY/RlWSNVPReTnWyFuyT8SPLrdQDsAtnr/M8TcQWMypxZmy30GRkhmjoOvd//C5nMqdTRoq3W8YuFhVfQcPwQBJBk2xyCFKhSwXacG15nG4pQ1GhR+b0K2Pzh1+GfgNaFpa2MC0CFDmDtpBJGyIKEyZdGf5CRq1zWX3vAhUAihQsRiSWWTbY5AOdKqx9SyQG5x4=X02ss

// admin details

Full name: Administrator
Email: admin@example.com
Username: admin
Password: admin

// notifications
don't configure email options

// finally the dashboard shows up

// stop JIRA

// execute following queries to set relative paths:
UPDATE propertystring SET propertyvalue = "./data/attachments" where ID = (SELECT ID FROM propertyentry where ENTITY_NAME = "jira.properties" and ENTITY_ID = 1 AND PROPERTY_KEY = "jira.path.attachments" AND propertytype = 5);
UPDATE propertystring SET propertyvalue = "./export" where ID = (SELECT ID FROM propertyentry where ENTITY_NAME = "jira.properties" and ENTITY_ID = 1 AND PROPERTY_KEY = "jira.path.backup" AND propertytype = 5);

// Do a db export
mysqldump -uroot -p jiradb > jira_63_mysql55_dump.sql
